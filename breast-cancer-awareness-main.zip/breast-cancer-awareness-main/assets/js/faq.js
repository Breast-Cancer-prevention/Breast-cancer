
// scroll revela js starts here 
ScrollReveal().reveal("#headingOne", {delay:300});
ScrollReveal().reveal("#headingTwo", {delay:350});
ScrollReveal().reveal("#headingThree", {delay:400});
ScrollReveal().reveal("#headingFour", {delay:450});
ScrollReveal().reveal("#headingFive", {delay:500});
ScrollReveal().reveal("#headingSix", {delay:550});
ScrollReveal().reveal("#headingSeven", {delay:600});
ScrollReveal().reveal("#headingEight", {delay:300});
ScrollReveal().reveal("#headingNine", {delay:300});
ScrollReveal().reveal("#headingTen", {delay:300});
ScrollReveal().reveal("#headingEleven", {delay:300});
ScrollReveal().reveal("#headingTwelve", {delay:300});
ScrollReveal().reveal("#headingThirteen", {delay:300});
ScrollReveal().reveal("#headingFourteen", {delay:300});
// scroll revela js ends here